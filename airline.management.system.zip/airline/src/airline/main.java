package airline;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.*;

class Airline {
    private int id;
    private String name;
    private List<Flight> flights;

    public Airline(int id, String name) {
        this.id = id;
        this.name = name;
        this.flights = new ArrayList<>();
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void addFlight(Flight flight) {
        flights.add(flight);
    }

    public List<Flight> getFlights() {
        return flights;
    }
}

class Flight {
    private int id;
    private String flightNumber;
    private String source;
    private String destination;
    private Date departureTime;
    private Date arrivalTime;
    private Airline airline;
    private List<Ticket> tickets;
    private List<Seat> seats;

    public Flight(int id, String flightNumber, String source, String destination, Date departureTime, Date arrivalTime, Airline airline) {
        this.id = id;
        this.flightNumber = flightNumber;
        this.source = source;
        this.destination = destination;
        this.departureTime = departureTime;
        this.arrivalTime = arrivalTime;
        this.airline = airline;
        this.tickets = new ArrayList<>();
        this.seats = new ArrayList<>();
    }

    public int getId() {
        return id;
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public String getSource() {
        return source;
    }

    public String getDestination() {
        return destination;
    }

    public Date getDepartureTime() {
        return departureTime;
    }

    public Date getArrivalTime() {
        return arrivalTime;
    }

    public Airline getAirline() {
        return airline;
    }

    public void addTicket(Ticket ticket) {
        tickets.add(ticket);
    }

    public List<Ticket> getTickets() {
        return tickets;
    }

    public void addSeat(Seat seat) {
        seats.add(seat);
    }

    public List<Seat> getSeats() {
        return seats;
    }
}

class Passenger {
    private int id;
    private String name;
    private String passportNumber;

    public Passenger(int id, String name, String passportNumber) {
        this.id = id;
        this.name = name;
        this.passportNumber = passportNumber;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getPassportNumber() {
        return passportNumber;
    }
}

class Ticket {
    private int id;
    private Passenger passenger;
    private Flight flight;
    private String seatNumber;

    public Ticket(int id, Passenger passenger, Flight flight, String seatNumber) {
        this.id = id;
        this.passenger = passenger;
        this.flight = flight;
        this.seatNumber = seatNumber;
    }

    public int getId() {
        return id;
    }

    public Passenger getPassenger() {
        return passenger;
    }

    public Flight getFlight() {
        return flight;
    }

    public String getSeatNumber() {
        return seatNumber;
    }
}

class Seat {
    private int id;
    private String seatNumber;
    private boolean isBooked;
    private Flight flight;

    public Seat(int id, String seatNumber, Flight flight) {
        this.id = id;
        this.seatNumber = seatNumber;
        this.isBooked = false;
        this.flight = flight;
    }

    public int getId() {
        return id;
    }

    public String getSeatNumber() {
        return seatNumber;
    }

    public boolean isBooked() {
        return isBooked;
    }

    public Flight getFlight() {
        return flight;
    }

    public void book() {
        isBooked = true;
    }
}

public class main {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/airline";
    private static final String USER = "kshitiz";
    private static final String PASSWORD = "veteran@24";

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in);
             Connection conn = DriverManager.getConnection(DB_URL, USER, PASSWORD)) {

            createTables(conn);

            while (true) {
                System.out.println("\n1. Add Airline");
                System.out.println("2. Add Flight");
                System.out.println("3. Book Ticket");
                System.out.println("4. Show All Flights");
                System.out.println("5. Exit");
                System.out.print("Enter your choice: ");
                int choice = scanner.nextInt();
                scanner.nextLine();  // Consume newline

                switch (choice) {
                    case 1:
                        addAirline(conn, scanner);
                        break;
                    case 2:
                        addFlight(conn, scanner);
                        break;
                    case 3:
                        bookTicket(conn, scanner);
                        break;
                    case 4:
                        showAllFlights(conn);
                        break;
                    case 5:
                        System.out.println("Exiting...");
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void createTables(Connection conn) throws SQLException {
        try (Statement stmt = conn.createStatement()) {
            String airlineTable = "CREATE TABLE IF NOT EXISTS airlines (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255))";
            String flightTable = "CREATE TABLE IF NOT EXISTS flights (id INT AUTO_INCREMENT PRIMARY KEY, flight_number VARCHAR(50), source VARCHAR(255), destination VARCHAR(255), departure_time DATETIME, arrival_time DATETIME, airline_id INT, FOREIGN KEY (airline_id) REFERENCES airlines(id))";
            String passengerTable = "CREATE TABLE IF NOT EXISTS passengers (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255), passport_number VARCHAR(50))";
            String ticketTable = "CREATE TABLE IF NOT EXISTS tickets (id INT AUTO_INCREMENT PRIMARY KEY, passenger_id INT, flight_id INT, seat_number VARCHAR(50), FOREIGN KEY (passenger_id) REFERENCES passengers(id), FOREIGN KEY (flight_id) REFERENCES flights(id))";
            String seatTable = "CREATE TABLE IF NOT EXISTS seats (id INT AUTO_INCREMENT PRIMARY KEY, seat_number VARCHAR(50), is_booked BOOLEAN, flight_id INT, FOREIGN KEY (flight_id) REFERENCES flights(id))";
            stmt.executeUpdate(airlineTable);
            stmt.executeUpdate(flightTable);
            stmt.executeUpdate(passengerTable);
            stmt.executeUpdate(ticketTable);
            stmt.executeUpdate(seatTable);
        }
    }

    private static void addAirline(Connection conn, Scanner scanner) throws SQLException {
        System.out.print("Enter airline name: ");
        String airlineName = scanner.nextLine();
        String sql = "INSERT INTO airlines (name) VALUES (?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, airlineName);
            stmt.executeUpdate();
            System.out.println("Airline added successfully!");
        }
    }

    private static void addFlight(Connection conn, Scanner scanner) throws SQLException {
        System.out.print("Enter flight number: ");
        String flightNumber = scanner.nextLine();
        System.out.print("Enter source: ");
        String source = scanner.nextLine();
        System.out.print("Enter destination: ");
        String destination = scanner.nextLine();
        System.out.print("Enter departure time (yyyy-MM-dd HH:mm): ");
        String departureTimeString = scanner.nextLine();
        Date departureTime = parseDate(departureTimeString);
        System.out.print("Enter arrival time (yyyy-MM-dd HH:mm): ");
        String arrivalTimeString = scanner.nextLine();
        Date arrivalTime = parseDate(arrivalTimeString);
        System.out.print("Enter airline ID: ");
        int airlineId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        String sql = "INSERT INTO flights (flight_number, source, destination, departure_time, arrival_time, airline_id) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, flightNumber);
            stmt.setString(2, source);
            stmt.setString(3, destination);
            stmt.setTimestamp(4, new Timestamp(departureTime.getTime()));
            stmt.setTimestamp(5, new Timestamp(arrivalTime.getTime()));
            stmt.setInt(6, airlineId);
            stmt.executeUpdate();
            System.out.println("Flight added successfully!");
        }
    }

    private static void bookTicket(Connection conn, Scanner scanner) throws SQLException {
        System.out.print("Enter passenger name: ");
        String passengerName = scanner.nextLine();
        System.out.print("Enter passenger passport number: ");
        String passportNumber = scanner.nextLine();
        System.out.print("Enter flight ID: ");
        int flightId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        String sql = "INSERT INTO passengers (name, passport_number) VALUES (?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, passengerName);
            stmt.setString(2, passportNumber);
            stmt.executeUpdate();

            ResultSet rs = stmt.getGeneratedKeys();
            int passengerId = 0;
            if (rs.next()) {
                passengerId = rs.getInt(1);
            }

            String bookSeatSql = "SELECT id, seat_number FROM seats WHERE flight_id = ? AND is_booked = FALSE LIMIT 1";
            try (PreparedStatement bookSeatStmt = conn.prepareStatement(bookSeatSql)) {
                bookSeatStmt.setInt(1, flightId);
                ResultSet seatResult = bookSeatStmt.executeQuery();
                if (seatResult.next()) {
                    int seatId = seatResult.getInt("id");
                    String seatNumber = seatResult.getString("seat_number");

                    String updateSeatSql = "UPDATE seats SET is_booked = TRUE WHERE id = ?";
                    try (PreparedStatement updateSeatStmt = conn.prepareStatement(updateSeatSql)) {
                        updateSeatStmt.setInt(1, seatId);
                        updateSeatStmt.executeUpdate();
                    }

                    String bookTicketSql = "INSERT INTO tickets (passenger_id, flight_id, seat_number) VALUES (?, ?, ?)";
                    try (PreparedStatement bookTicketStmt = conn.prepareStatement(bookTicketSql)) {
                        bookTicketStmt.setInt(1, passengerId);
                        bookTicketStmt.setInt(2, flightId);
                        bookTicketStmt.setString(3, seatNumber);
                        bookTicketStmt.executeUpdate();
                        System.out.println("Ticket booked successfully!");
                    }
                } else {
                    System.out.println("No available seats on this flight.");
                }
            }
        }
    }

    private static void showAllFlights(Connection conn) throws SQLException {
        System.out.println("All Flights:");
        String sql = "SELECT flights.*, airlines.name AS airline_name FROM flights JOIN airlines ON flights.airline_id = airlines.id";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                int id = rs.getInt("id");
                String flightNumber = rs.getString("flight_number");
                String source = rs.getString("source");
                String destination = rs.getString("destination");
                Date departureTime = rs.getTimestamp("departure_time");
                Date arrivalTime = rs.getTimestamp("arrival_time");
                String airlineName = rs.getString("airline_name");

                System.out.println("Flight ID: " + id);
                System.out.println("Flight Number: " + flightNumber);
                System.out.println("Source: " + source);
                System.out.println("Destination: " + destination);
                System.out.println("Departure Time: " + departureTime);
                System.out.println("Arrival Time: " + arrivalTime);
                System.out.println("Airline Name: " + airlineName);
                System.out.println();
            }
        }
    }

    private static Date parseDate(String dateString) {
        try {
            return new SimpleDateFormat("yyyy-MM-dd HH:mm").parse(dateString);
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }
}

